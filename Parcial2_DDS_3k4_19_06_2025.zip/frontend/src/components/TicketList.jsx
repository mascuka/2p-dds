function TicketList() {
    return (
        <div>
            <h1>Lista de Tickets</h1>
        </div>
    );
}

export default TicketList;