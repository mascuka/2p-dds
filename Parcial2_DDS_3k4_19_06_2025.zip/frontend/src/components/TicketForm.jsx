function TicketForm() { 
  return (
    <div>
      <h1>Formulario de Tickets</h1>
    </div>
  );
}

export default TicketForm;